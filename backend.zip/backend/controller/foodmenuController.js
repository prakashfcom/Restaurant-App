const asyncHandler =require('express-async-handler');
const Foodmenu =require('../models/foodmenuModel');
const foodcategory =require('../models/foodcategoryModel');
const Ingredients =require('../models/ingredientsModel');
const vat =require('../models/vatModel');
const { default: mongoose } = require("mongoose");

const multer = require('multer');
const Schema = mongoose.Schema;
const itemSchema = new Schema({ data: String });



const getfoodCategory =asyncHandler(async (req,res) =>{
    try {
        const getfoodcat = await foodcategory.find();
        res.json(getfoodcat);
      } catch (error) {
        throw new Error(error);
      }

});

const getingredients =asyncHandler(async (req,res) =>{
    try {
        const geting = await Ingredients.find();
        res.json(geting);
      } catch (error) {
        throw new Error(error);
      }

});

const getvat =asyncHandler(async(req,res) =>{
    try {
        const getvat = await vat.find();
        res.json(getvat);
      } catch (error) {
        throw new Error(error);
      }
});

// const storage = multer.diskStorage({
//   destination: function (req, file, cb) {
//     cb(null, 'uploads/'); // The directory where files will be stored
//   },
//   filename: function (req, file, cb) {
//     cb(null, file.originalname); // Use the original filename
//   },
// });

// const upload = multer({ storage: storage });


// const creatFoodmenu =asyncHandler(async(req,res) =>{

//   const foodmenuname =req.body.foodmenuname;
//   // const upload = multer({ storage }).single("photo");
//   const findFoodmenu =await Foodmenu.findOne({ foodmenuname:foodmenuname });
//   if(!findFoodmenu)
//   {
//       //Create a new User
//       const newFoodcategory =Foodmenu.create(req.body);
//       res.json(newFoodcategory);
//   }
//   else{
     
//       throw new Error("Foodmenu Name Already Exist");

//   }



// });

const creatFoodmenu = asyncHandler(async (req, res) => {

  const foodmenuname =req.body.foodmenuname;

  const findFoodmenu =await Foodmenu.findOne({ foodmenuname:foodmenuname });

  if (!findFoodmenu) {
    // Configure multer for file upload
    const storage = multer.diskStorage({
      destination: function (req, file, cb) {
        cb(null, 'public/images/'); // Define the directory where uploaded files will be stored
      },
      filename: function (req, file, cb) {
        cb(null, Date.now() + '-' + file.originalname); // Define the file name
      },
    });

    const upload = multer({ storage }).single('photo'); // Assuming 'photo' is the field name for the uploaded image

    upload(req, res, async function (err) {
      if (err) {
        return res.status(500).json({ message: 'Error uploading file' });
      }

      // Assuming the file URL is stored in req.file.filename
      const imageFileUrl = req.file;

      // Create a new food menu item with the image file URL
      const newFoodCategory = await Foodmenu.create({
        foodmenuname,
        
        photo: imageFileUrl,
        // Other properties from req.body
      });

      res.json(newFoodCategory);
    });
  } else {
    res.status(400).json({ message: 'Food Menu Name Already Exists' });
  }
});



const getallfoods =asyncHandler(async(req,res) =>{


  try {
    const foodmenu = await Foodmenu.aggregate([
      {
        $lookup: {
          from: 'foodcategories',
          localField: 'foodcategoryId',
          foreignField: '_id',
          as: 'foodcategory',
        },
      },
      {
        $unwind: '$foodcategory',
      },
      {
        $lookup: {
          from: 'vats',
          localField: 'vatId',
          foreignField: '_id',
          as: 'vat',
        },
      },
      {
        $unwind: '$vat',
      },
    ]);
  
    res.json(foodmenu);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'An error occurred' });
  }

});



module.exports = {getfoodCategory,getingredients,getvat,creatFoodmenu,getallfoods};